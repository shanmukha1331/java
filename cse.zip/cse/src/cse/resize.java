package cse;
import java.util.Arrays;

public class resize {

	public static void main(String[] args) {
int[] originalArray = {1, 2, 3, 4, 5};
        
        System.out.println("Original array: " + Arrays.toString(originalArray));
        
        int[] resizedArray = Arrays.copyOf(originalArray, 10);
        
        System.out.println("Resized array (size 10): " + Arrays.toString(resizedArray));
    }
}

