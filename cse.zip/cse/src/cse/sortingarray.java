package cse;
import java.util.Arrays; 

public class sortingarray {

	public static void main(String[] args) {
        int[] studentMarks = {85, 72, 91, 68, 79, 95, 88};

        System.out.println("Original student marks: " + Arrays.toString(studentMarks));

       
        Arrays.sort(studentMarks);

        System.out.println("Student marks after sorting (ascending): " + Arrays.toString(studentMarks));


	}

}
