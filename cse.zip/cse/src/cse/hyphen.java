package cse;
import java.util.Scanner;

public class hyphen {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		        System.out.print("Enter a string: ");
		        String input = scanner.nextLine();
		        String result = input.replace(' ', '-');
		        System.out.println("Modified string: " + result);

		        scanner.close();
		    }
		}

