package cse;
import java.util.Scanner;
public class split {

	public static void main(String[] args) {
	   Scanner scanner=new Scanner(System.in);
	   System.out.println("enter full name:");
	   String fullname=scanner.nextLine();
	   String[] nameParts = fullname.split(" ");
       if (nameParts.length >= 2) {
           String firstName = nameParts[0];
           String lastName = nameParts[1];

           System.out.println("First Name: " + firstName);
           System.out.println("Last Name: " + lastName);
       } else {
           System.out.println("Please enter both first and last names separated by a space.");
       }

       scanner.close();

	   
	   

	}

}
