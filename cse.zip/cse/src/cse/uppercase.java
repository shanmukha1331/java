package cse;
import java.util.Scanner;

public class uppercase {

	public static void main(String[] args) {
	Scanner sin=new Scanner(System.in);
	System.out.println("enter the string");
	String sentence=sin.nextLine();
    String uppercaseSentence = sentence.toUpperCase();
    System.out.println("Uppercase sentence: " + uppercaseSentence);
    sin.close();}

}
