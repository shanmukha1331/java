package cse;
import java.util.Scanner;
public class wordfrequency {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
System.out.print("Enter a sentence: ");
		        String sentence = sc.nextLine();
		        String[] words = sentence.split(" ");
		        boolean[] counted = new boolean[words.length];
		        for (int i = 0; i < words.length; i++) {
		            if (!counted[i]) {
		                int count = 1;
		                for (int j = i + 1; j < words.length; j++) {
		                    if (words[i].equals(words[j])) {
		                        count++;
		                        counted[j] = true; // mark as counted
		                    }
		                }
		                System.out.println(words[i] + " : " + count);
		            }
		        }
sc.close();
}
}
