package cse;
import java.util.Scanner;

public class trim {

	public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
		        System.out.print("Enter a string with leading/trailing spaces: ");
		        String input = scanner.nextLine();
		        String trimmed = input.trim();
		        System.out.println("String after trim: '" + trimmed + "'");
		        scanner.close();
		    }
		}

