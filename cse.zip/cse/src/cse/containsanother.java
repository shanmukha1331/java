package cse;

public class containsanother {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str1="Shanmukharamireddy";
		String str2="reddy";
		boolean s=str1.contains(str2);
		System.out.println(s);
		

	}

}
