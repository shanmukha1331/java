package cse;
import java.util.Arrays;
import java.util.Scanner;
public class sort {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
                System.out.print("Enter a string: ");
		        String input = sc.nextLine();
		        char[] charArray = input.toCharArray();
		        Arrays.sort(charArray);
		        String sortedString = new String(charArray);
                 System.out.println("Sorted string: " + sortedString);
                 sc.close();
		    }
		}
