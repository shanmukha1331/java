package cse;
import java.util.Scanner;


public class domain {

	public static void main(String[] args) {
		Scanner sin = new Scanner(System.in);
		System.out.println("enter string");
		String str=sin.next();
		
		int  index=str.indexOf('@');
		String domain=str.substring(index+1);
		System.out.println(domain);
		
		

	}

}
