package cse;

import java.util.Arrays;

public class fillarray {

	public static void main(String[] args) {
	
		int [] arr1= {2,2,2,2,8,8};
		System.out.println(Arrays.toString(arr1));
		
		Arrays.fill(arr1, -1);
		System.out.println("afterfill array");
		System.out.println(Arrays.toString(arr1));
	}

}
