package cse;

import java.util.Scanner;

public class caseinsensitive {

	public static void main(String[] args) {
	String storedusername="Shannu";
	String storedpassword="97010";
	Scanner sin = new Scanner(System.in);
	System.out.println("enter inputusername");
	String inputuser = sin.nextLine();
	System.out.println("enter password");
	String password = sin.nextLine();
	if(storedusername.equalsIgnoreCase(inputuser)&& storedpassword.equalsIgnoreCase(password)) {
		System.out.println("succeessful.......");
	}
	else {
		System.out.println("not sucessfulll....");
	}


	}

}
