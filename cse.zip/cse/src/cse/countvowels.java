package cse;
import java.util.Scanner;

public class countvowels {

	public static void main(String[] args) {
		Scanner sin=new Scanner(System.in);
		System.out.println("Enter a word");
		String word=sin.nextLine();
		word = word.toLowerCase();
        int vowelCount = 0;
        for (int i = 0; i < word.length(); i++) {
            char ch = word.charAt(i);
            if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
                vowelCount++;
            }
        }
        System.out.println("Number of vowels: " + vowelCount);
        sin.close();
        }
}
