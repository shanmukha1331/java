package cse;
import java.util.Arrays;
import java.util.Scanner;


public class array {
            public class sorting {

	}

			public static void main(String[] args) {
            	Scanner sin=new Scanner(System.in);
            	System.out.println("enter the elements of array");
            	int n=sin.nextInt();
            	int[] arr1= new int[n];
            	System.out.println("enter "+n+ "integer");
            	for(int i=0;i<n;i++)
            	{
            		arr1[i]=sin.nextInt();
            	}
            	System.out.println("ARRAY IS" +Arrays.toString(arr1));
            	sin.close();
            }
}
