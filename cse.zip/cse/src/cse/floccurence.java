package cse;
import java.util.Scanner;
public class floccurence {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a string: ");
        String input = scanner.nextLine();
        System.out.print("Enter a letter to find: ");
        char letter = scanner.next().charAt(0);
        int firstIndex = input.indexOf(letter);
        int lastIndex = input.lastIndexOf(letter);
        if (firstIndex == -1) {
            System.out.println("Letter '" + letter + "' not found in the string.");
        } else {
            System.out.println("First occurrence of '" + letter + "' is at index: " + firstIndex);
            System.out.println("Last occurrence of '" + letter + "' is at index: " + lastIndex);
        }

        scanner.close();


	}

}
