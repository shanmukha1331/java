package cse;
import java.util.Scanner;
public class mostrepeated {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
System.out.print("Enter a string: ");
		        String input = sc.nextLine();
char[] chars = input.toCharArray();
		        int maxCount = 0;
		        char mostRepeated = ' ';
		        for (int i = 0; i < chars.length; i++) {
		            int count = 1;
		            for (int j = i + 1; j < chars.length; j++) {
		                if (chars[i] == chars[j]) {
		                    count++;
		                }
		            }
		            if (count > maxCount) {
		                maxCount = count;
		                mostRepeated = chars[i];
		            }
		        }
                 System.out.println("Most repeated character: " + mostRepeated);
		        System.out.println("Count: " + maxCount);
		        sc.close();
		    }
		}


