package cse;

public class primenumber {

	public static void main(String[] args) {
	

	}

}
