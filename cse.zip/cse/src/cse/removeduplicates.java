package cse;

import java.util.Arrays;

public class removeduplicates {


	public static void main(String[] args) {
		int []arr= {1,1,2,2,2,3,3,3,3,4,4,5,7,8,};
				Arrays.sort(arr);
				System.out.println("before removing duplicates");
		System.out.println("after removing duplicates");
		System.out.print(arr[0] + " ");
        for (int i = 1; i < arr.length; i++) {
            if (arr[i] != arr[i - 1]) {
                System.out.print(arr[i] + " ");
            }
        }
		}
}
